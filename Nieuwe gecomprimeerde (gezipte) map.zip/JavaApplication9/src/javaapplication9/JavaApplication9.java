package javaapplication9;
public class JavaApplication9
{
    public static void main(String[] args)
    {
        System.out.println("BGGGJHG");
    }
    
}
